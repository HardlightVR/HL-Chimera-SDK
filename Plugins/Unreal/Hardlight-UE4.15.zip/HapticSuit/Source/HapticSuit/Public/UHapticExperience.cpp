// Copyright 1998-2016 Epic Games, Inc. All Rights Reserved.

#include "HapticSuitPrivatePCH.h"
#include "UHapticExperience.h"


UHapticExperience::UHapticExperience(const FObjectInitializer& ObjectInitializer) :Super(ObjectInitializer) {

}



